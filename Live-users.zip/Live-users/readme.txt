1.	Include the given send-request.php at the bottom of each of your application files

2.	'send-request.php' will call 'store-users.php' automatically through AJAX.

3.	'store-users.php' uses session values to store user information (here user id will be stored)

4.	'store-users.php' inserts user information continuously at the given interval(35 sec)

5.	'view-users.php' displays records by reading 'online-users.txt', here reading data and emptying the file will happen
